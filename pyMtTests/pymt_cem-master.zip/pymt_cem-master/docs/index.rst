Welcome to pymt_cem's documentation!
====================================
.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   modules
..   usage
..   contributing

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
